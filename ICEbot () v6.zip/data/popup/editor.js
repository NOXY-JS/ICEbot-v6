/* global table */
'use strict';
function LUNA_(...v){
  let obj = [];obj = obj.concat(v, Math.random() * 10000);chrome.storage.local.set({message: JSON.stringify(obj)});
}
function f(ICE){return document.querySelector(ICE)}
function fa(ICE){return document.querySelectorAll(ICE)}
let avataritem = localStorage.getItem("avatar");
if (!avataritem) {
  localStorage.setItem("avatar", 1);

}

        if (avataritem!=='random' && avataritem!=='null' && avataritem) {setTimeout(()=>{
f("#avatar").src = "https://gartic.io/static/images/avatar/svg/"+avataritem+".svg";},0)
                                }
        if (avataritem=='null') {setTimeout(()=>{
f("#avatar").src = "https://garticphone.com/images/avatar/31.svg";},1000)
                                }
        if (avataritem=='random') {setTimeout(()=>{
f("#avatar").src = "https://gartic.io/static/images/subjects/1.svg?v=1";},1000)
                                }
                                     let nickitem = localStorage.getItem("nick");
if (!nickitem) {
  localStorage.setItem("nick", "ICEbot");
}
document.addEventListener('input', e => {
  const cmd = e.target.dataset.cmd;
              if(cmd=='nick'){localStorage.setItem("nick",f("#nick").value)}
  })
document.addEventListener('click', e => {
  const cmd = e.target.dataset.cmd;
  
  if (cmd === 'join') {
new Promise(resolve => {
  chrome.cookies.getAll({name: 'garticio@gartic.io'}, cookies => {
    cookies.forEach(cookie => {
      chrome.cookies.remove({
        url: cookie.secure ? "https://" + cookie.domain + cookie.path : "http://" + cookie.domain + cookie.path,   name: 'garticio@gartic.io'    });   });   resolve(); });});
        let i= f("#url").value
        let c= localStorage.getItem("nick")
        let e=localStorage.getItem("avatar")
        let bot= localStorage.getItem("botnick")

LUNA_("join",i,c,e,bot)}
    if (cmd === 'broadcast') {var broadcast=f("#broadcast").value;LUNA_("broadcast",broadcast)}
    if (cmd === 'broadcastspam') {var broadcastspam=f("#broadcast").value;LUNA_("broadcastspam",broadcastspam)}
    if (cmd === 'msg') {var msg=f("#message").value;LUNA_("msg",msg)}
    if (cmd === 'msgspam') {var msgspam=f("#message").value;LUNA_("msgspam",msgspam)}
    if (cmd === 'answer') {var answer=f("#answer").value;LUNA_("answer",answer)}
    if (cmd === 'answerspam') {var answerspam=f("#answer").value;LUNA_("answerspam",answerspam)}
    if (cmd==='exit') {LUNA_("exit")}
    if (cmd==='report') {LUNA_("report")}
    if (cmd==='jump') {LUNA_("jump")}
    if (cmd==='tips') {LUNA_("tips")}
    if (cmd==='afkconfirm') {LUNA_("afkconfirm")}
    if (cmd==='reconnect') {LUNA_("reconnect")}
    if (cmd==='accept1') {LUNA_("accept1")}
    if (cmd==='accept2') {LUNA_("accept2")}    
    if (cmd==='rejoin') {LUNA_("rejoin");setTimeout(()=>{LUNA_("join");},16)}
    if(cmd==='botnick1'){localStorage.setItem("botnick","0")}
    if(cmd==='botnick2'){localStorage.setItem("botnick","1")}
    if(cmd=="showavatarlist"){
        f("#icebot1").style.display="none"
        f("#avatarlist").style.display="block"
    }
    if(cmd=="hideavatarlist"){
        f("#icebot1").style.display="block"
        f("#avatarlist").style.display="none"
    }
    if(cmd.indexOf("avatar.")!=-1){
                let a=cmd.split("avatar.")[1]
switch(a) {
  case '0':case '1':case '2':case '3':case '4':case '5':case '6':case '7':case '8':case '9':case '10':case '11':case '12':case '13':case '14':case '15':case '16':case '17':case '18':case '19':case '20':case '21':case '22':case '23':case '24':case '25':case '26':case '27':case '28':case '29':case '30':case '31':case '32':case '33':case '34':case '35':case '36':
f("#avatar").src = "https://gartic.io/static/images/avatar/svg/"+a+".svg";
localStorage.setItem("avatar",a)
    break;
    case 'null':

f("#avatar").src = "https://garticphone.com/images/avatar/31.svg";
localStorage.setItem("avatar",null)
break;
    case 'random':
f("#avatar").src = "https://gartic.io/static/images/subjects/1.svg?v=1";
localStorage.setItem("avatar",'random')
        break
            }}
                if(cmd.indexOf("cavt.")!=-1){
                let a=cmd.split("cavt.")[1]
switch(a) {
  case '0':case '1':case '2':case '3':case '4':case '5':case '6':case '7':case '8':case '9':case '10':case '11':case '12':case '13':case '14':case '15':case '16':case '17':case '18':case '19':case '20':case '21':case '22':case '23':case '24':case '25':case '26':case '27':case '28':case '29':case '30':case '31':case '32':case '33':case '34':case '35':case '36':
f("#cavatar").src = "https://gartic.io/static/images/avatar/svg/"+a+".svg";
localStorage.setItem("cavatar",a)
  document.querySelector('#cavatarlist').style.display='none';document.querySelector('#custombotnick').style.display='block'
    break;
    case 'null':

f("#cavatar").src = "https://garticphone.com/images/avatar/31.svg";
localStorage.setItem("cavatar",null)
  document.querySelector('#cavatarlist').style.display='none';document.querySelector('#custombotnick').style.display='block'
break;
    case 'random':
f("#cavatar").src = "https://gartic.io/static/images/subjects/1.svg?v=1";
localStorage.setItem("cavatar",'random')
  document.querySelector('#cavatarlist').style.display='none';document.querySelector('#custombotnick').style.display='block'
        break
            }}
    if (cmd === 'setcustomnick') {
    	let cavatar=parseInt(localStorage.getItem("cavatar"))
    	let cnick=document.querySelector("#customnick").value
    	document.querySelector("#cstbtn").innerHTML += `
<button style="width:100%; height:60px;position: relative;">
    <img width="50" height="50" style="position: absolute; left: 0; top: 0;" src="https://gartic.io/static/images/avatar/svg/`+cavatar+`.svg">
    <span style="position: relative; top: -0px; left: 30px;">`+cnick+`</span>
</button>
`;

    	}
        if (cmd === 'customavatar') {
        	document.querySelector('#cavatarlist').style.display='block';document.querySelector('#custombotnick').style.display='none'
        	}
        
    if(cmd=="hidecavatarlist"){
        	document.querySelector('#cavatarlist').style.display='none';document.querySelector('#custombotnick').style.display='block'
    }
        if(cmd=="cnickclose"){
        	document.querySelector('#custombotnick').style.display='none';
    }
        if(cmd=="cnickshow"){
        	document.querySelector('#custombotnick').style.display='block';
    }
});
