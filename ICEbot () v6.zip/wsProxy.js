
var scriptString = (function() {
	let autoreport=false,autoskip=false,antikick=false,antiafk=false,autokick=false,autoguess=false,giveanswer=false,autotips=false,intervalantiafk;
     window.addEventListener("message",function(msg){
        if(typeof(msg.data)==="string"){
        	 if(msg.data.indexOf("votedkick.")!=-1){
let a = msg.data.split("votedkick.")[1].split('.')[0];
let b = msg.data.split('.')[2].split('.')[0];

let c = msg.data.split('.').slice(3).join('.');
const Toast = Swal.mixin({ toast: true, position: "top-end", showConfirmButton: false, timer: 3000, timerProgressBar: true, didOpen: (toast) => { toast.onmouseenter = Swal.stopTimer; toast.onmouseleave = Swal.resumeTimer; } });if(c==='undefined'){Toast.fire({ iconHtml: '<img src="https://gartic.io/static/images/avatar/svg/'+b+'.svg" style="height: 50px; width: 50px;">', title: a + " voted to kick" });} else { Toast.fire({ iconHtml: '<img src="'+c+'" style="height: 50px; width: 50px;">', title: a + " voted to kick" });}
                }
            if(msg.data=="roomsee"){
      let theme=slctt.value;
      let language=slctl.value;
          fetch("https://gartic.io/req/list/?search=&language[]="+parseInt(language)+(theme==="all"?'':"&subject[]="+parseInt(theme)))
    .then(response => response.json())
    .then(data => {
        let htmlContent = "";
        data.forEach(item => {
            if (item.quant > 0) {
                htmlContent += `<div class="avatarbtn"><button style="text-decoration: none;margin: 0;outline: none;line-height: 1;text-size-adjust: none;-webkit-tap-highlight-color: transparent;user-select: none;-webkit-font-smoothing: antialiased;box-sizing: border-box;cursor: pointer;border: none;background: #FFD700;color: #000000;padding: 10px 10px;border-radius: 50px;font-size: 11pt;margin-top: 5px;"><img style="width:50px;height:50px" src="https://gartic.io/static/images/subjects/${item.subject}.svg?v=1"></div><input type="submit" style="width:100%; white-space:pre-wrap;" value="${item.official ? '✅' : '☑'} ${getSL(item.subject, item.lang)} #${item.id.substring(1,4)} \nPlayers: ${item.quant}/${item.max} | Goal: ${item.points}/${item.goal}"><br><input type="submit" style="width:33%" value="/viewer" onclick="javascript:location.href='https://gartic.io/${item.code}/viewer'"><input type="submit" style="width:33%" value="Go" onclick="javascript:location.href='https://gartic.io/${item.code}'"><input type="submit" style="width:33%" value="Copy" onclick="javascript:navigator.clipboard.writeText('https://gartic.io/${item.code}')">`;
            }
        });
        document.querySelector("#roomson").innerHTML = htmlContent;
    });
                            	}
  if(msg.data=="autoreportp"){autoreport=document.querySelector("#autoreportplayer").checked;}
  if(msg.data=="autoskipp"){autoskip=document.querySelector("#autoskipplayer").checked;}
  if(msg.data=="antikickp"){antikick=document.querySelector("#antikickplayer").checked;}
  if(msg.data=="antiafkp"){antiafk=document.querySelector("#antiafkplayer").checked;if(document.querySelector("#antiafkplayer").checked===true){intervalantiafk = setInterval(()=> {g('afkconfirm','1'); }, 10000);} else {clearInterval(intervalantiafk);}
}
  if(msg.data=="autokickp"){autokick=document.querySelector("#autokickplayer").checked;}
  if(msg.data=="autoguessp"){autoguess=document.querySelector("#autoguessplayer").checked;}
  if(msg.data=="giveanswerp"){giveanswer=document.querySelector("#giveanswerplayer").checked;}
  if(msg.data=="autotipsp"){autotips=document.querySelector("#autotipsplayer").checked;}
       if(msg.data=="kickall"){

    window.roomusers.forEach((u, i) => {
    if (window.longID!==u.id && !window.whitelist.includes(u.id)) {
        setTimeout(() => {
            window.postMessage('kickuser.' + u.id, '*'); 
        }, 350 * i); }
        
    });
       	}
               	    if(msg.data=="proxyactive"){
               	const Toast = Swal.mixin({ toast: true, position: "top-end", showConfirmButton: false, timer: 6000, timerProgressBar: true, didOpen: (toast) => { toast.onmouseenter = Swal.stopTimer; toast.onmouseleave = Swal.resumeTimer; } }); Toast.fire({ icon: "info", title: "Proxy cookies are updated. Now click on 'refresh all' to enable proxy servers." });
               	}
        	    if(msg.data=="info"){Swal.fire({ title: "ICEbot v6.0.0", html: "• Unlimited requests (429 bypass)<br>• Bot dupe<br>• Anti afk fixed<br>• Custom bot added<br>• ICEbot is now using only one tab to make bots<br>• RECONNECT resource is now removed due to make bot slower<br>• Over 70 free proxies to use<br>• Proxy selector added<br>• Auto kick fixed<br>• More bot nick added<br>•Bug fixes", icon: "info", allowOutsideClick: false })}
                        if(msg.data.indexOf("colorbot.")!=-1){
 let id = msg.data.split("colorbot.")[1];
if (!window.whitelist.find(item => item === id)) {
    window.whitelist.push(id);
  }
function dxle(de){ 
	    function FindReact(dom) { for (var key in dom) { if (key.startsWith("__reactInternalInstance$")) { var compInternals = dom[key].key; return compInternals; } } return null; };
document.querySelectorAll("span.nick").forEach(x=>{if(FindReact(x.parentElement.parentElement)===de){x.parentElement.parentElement.style.backgroundImage="linear-gradient(rgba(0,0,0,0.2),rgba(0,0,0,0.2)";x.style.color="#510ac9";
}})};dxle(id);
 }
        }})

	function LUNA(o, pN, c) {let v = o[pN];Object.defineProperty(o, pN, {get() {return v;},set(nV) {if (nV !== v) {const oV = v;v = nV;c(nV, oV);}},});}
const de= {exit: 10, rdraw: 10,kick: 10,answer: 10, chat: 10, jump: 10, report:10, afkconfirm:10, };
    function g(e, x) {
        switch(e){
            case 'exit':
  de.exit = [e,x,Math.ceil(Math.random()*100000+1)];
                break
            case 'rdraw':
  de.rdraw= [e,x,Math.ceil(Math.random()*100000+1)];
                break
            case 'kick':
  de.kick= [e,x,Math.ceil(Math.random()*100000+1)];
                break
            case 'answer':
  de.answer= [e,x,Math.ceil(Math.random()*100000+1)];console.log(1)
                break
            case 'chat':
  de.chat= [e,x,Math.ceil(Math.random()*100000+1)];
                break
                
            case 'jump':
  de.jump= [e,x,Math.ceil(Math.random()*100000+1)];
                break
                
            case 'report':
  de.report= [e,x,Math.ceil(Math.random()*100000+1)];
                break
                
            case 'afkconfirm':
  de.afkconfirm= [e,x,Math.ceil(Math.random()*100000+1)];
                
        }
    }
    let sE=[],lE=[];setTimeout(()=>{sE=window.__NEXT_DATA__.props.data.subjects,lE=window.__NEXT_DATA__.props.data.languages;localStorage.setItem("languages",JSON.stringify(window.__NEXT_DATA__.props.data.languages));localStorage.setItem("subjects",JSON.stringify(window.__NEXT_DATA__.props.data.subjects));},3000);let arfSL=[];function gSL(s, l) {const sO=sE.find(item => item.id === s);const lO= lE.find(item => item.id === l);if(sO && lO) {arfSL=[sO.name,lO.name];window.argsSL=arfSL;setTimeout(()=>{document.querySelector(".roomtheme").innerHTML= arfSL[0] +","+arfSL[1]},10)}}
    let emSL=[];function getSL(s, l) {const sO=sE.find(item => item.id === s);const lO= lE.find(item => item.id === l);if(sO && lO) {emSL=[sO.name,lO.name];window.emsSL=emSL; return emSL;}}
  if (window.Proxy == undefined) return;
  var oldWS = window.WebSocket;
  var loggerIncrement = 1;
  
  function processDataForOutput(data) {
    if (typeof data == 'string') return data;
    else if (data.byteLength != undefined) {
      var val = { orig: data, uintarr: new Uint8Array(data) };
      var arr = [], i = 0;
      for (; i < data.byteLength; i++) {
        arr.push(val.uintarr[i]);
      }
      var hexarr = arr.map(function (i) { var s = i.toString(16); while (s.length < 2) s = '0' + s; return s; });
      val.hexstr = hexarr.join('');
      val.string = unescape(hexarr.map(function (i) { return '%' + i; }).join(''));
      val.b64str = btoa(val.string);
      try {
        val.string = decodeURIComponent(escape(val.string));
      } catch (e) { }
      return val;
    }
  }

  var proxyDesc = {
    set: function (target, prop, val) {
      if (prop == 'onmessage') {
        var oldMessage = val;
        val = function (e) {
function fset(el,id){
	
if(el.className!=="userlist"){setTimeout(()=>{if(el.lastChild.lastChild.className!=="btn no-style"){
	if (window.__NEXT_DATA__.query.data.mobile===true && window.__NEXT_DATA__.page!=="/viewer"){el.lastChild.insertAdjacentHTML("afterend", `<div><input type="submit" class="btn no-style" style="z-index:9999999; background: white; border: none; cursor: pointer; position:absolute; left: 128px; top: 10px; width:25px;height:25px;border-radius:25px;" value="🚫" onclick="javascript:window.parent.postMessage('kickuser.`+id+`','*');setTimeout(()=>{document.querySelector('#popUp > div > div > button').click();document.querySelector('#popUp').style.display='none';},0);"></div>`);el.lastChild.insertAdjacentHTML("afterend", `<div><input type="submit" class="btn no-style" style="z-index:9999999; background: white; border: none; cursor: pointer; position:absolute; left: 158px; top: 10px; width:25px;height:25px;border-radius:25px;" value="⚠️" onclick="javascript:window.parent.postMessage('reportone.`+id+`','*');setTimeout(()=>{document.querySelector('#popUp > div > div > button').click();document.querySelector('#popUp').style.display='none';},0);"></div>`);} else { el.lastChild.insertAdjacentHTML("afterend", `<div><input type="submit" class="btn no-style" style="z-index:9999999; background: white; border: none; cursor: pointer; position:absolute; left: 210px; top: 21px; width:25px;height:25px;border-radius:25px;" value="🚫" onclick="javascript:window.parent.postMessage('kickuser.`+id+`','*');setTimeout(()=>{document.querySelector('#popUp > div > div > button').click();document.querySelector('#popUp').style.display='none';},0);"></div>`);}
}},2000) };}
        	function uptd(){
window.FindReact = function(dom) { for (var key in dom) { if (key.startsWith("__reactInternalInstance$")) { var compInternals = dom[key].key; return compInternals; } } return null; };
userElements = document.querySelectorAll('div[class*="user"]:not([class*="empty"]):not([class*="tools"]'); userElements.forEach(element => {
let key=FindReact(element);
if(element.className!=="userlist"){setTimeout(()=>{if(element.lastChild.lastChild.className!=="btn no-style"){if (window.__NEXT_DATA__.query.data.mobile===true && window.__NEXT_DATA__.page!=="/viewer"){element.lastChild.insertAdjacentHTML("afterend", `<div><input type="submit" class="btn no-style" style="z-index:9999999; background: white; border: none; cursor: pointer; position:absolute; left: 128px; top: 10px; width:25px;height:25px;border-radius:25px;" value="🚫" onclick="javascript:window.parent.postMessage('kickuser.`+key+`','*');setTimeout(()=>{document.querySelector('#popUp > div > div > button').click();document.querySelector('#popUp').style.display='none';},0);"></div>`);} else {element.lastChild.insertAdjacentHTML("afterend", `<div><input type="submit" class="btn no-style" style="z-index:9999999; background: white; border: none; cursor: pointer; position:absolute; left: 210px; top: 21px; width:25px;height:25px;border-radius:25px;" value="🚫" onclick="javascript:window.parent.postMessage('kickuser.`+key+`','*');setTimeout(()=>{document.querySelector('#popUp > div > div > button').click();document.querySelector('#popUp').style.display='none';},0);"></div>`);}}},2000) }});}
function dxle(de){ document.querySelectorAll("span.nick").forEach(x=>{if(FindReact(x.parentElement.parentElement)===de){x.parentElement.parentElement.style.backgroundImage="linear-gradient(rgba(0,0,0,0.2),rgba(0,0,0,0.2)";x.style.color="red"}})};
function ej(d){return Array.from(document.querySelectorAll('span.nick')).find(el => el.textContent === d)};
                  function updatespeckicks(){
        document.querySelector(".userkickmenu").innerHTML=""
        switch(localStorage.getItem("theme")){
            case 'white':case 'yellow':
        window.roomusers.forEach(user=>{
            user.nick.split("").join("")!="ICEbot"?document.querySelector(".userkickmenu").innerHTML+=`<input type="submit" class="kickmenubtn" style="background-color:`+localStorage.getItem("theme")+`;color:black;" value="`+user.nick+`" onclick="window.postMessage('kickuser.`+user.id+`','*')">`:0

        }); break;
            case 'red':case 'orange': case 'green': case 'blue': case 'indigo': case 'violet': case 'pink': case 'crimson': case 'brown': case 'gray': case 'black': case 'magenta':window.roomusers.forEach(user=>{
            user.nick.split("").join("")!="ICEbot"?document.querySelector(".userkickmenu").innerHTML+=`<input type="submit" class="kickmenubtn" style="background-color:`+localStorage.getItem("theme")+`;color:white;" value="`+user.nick+`" onclick="window.postMessage('kickuser.`+user.id+`','*')">`:0
        });
                break;
            default:
        window.roomusers.forEach(user=>{
            user.nick.split("").join("")!="ICEbot"?document.querySelector(".userkickmenu").innerHTML+=`<input type="submit" class="kickmenubtn" value="`+user.nick+`" onclick="window.postMessage('kickuser.`+user.id+`','*')">`:0
        })
        };
    }
          let d=processDataForOutput(e.data);
          let de=d.substring(2)
                if(d.indexOf('42["5"')!=-1){
                    window.roomusers=[];
                    window.whitelist=[];
                    let objlist=JSON.parse('["5"'+d.split('42["5"')[1]);console.log(objlist[5])
                    objlist[5].forEach(item=>{window.roomusers.push(item)});
                    window.id=objlist[2]
                    window.longID=objlist[1]
                    window.tipo=objlist[4].tipo
                    window.idioma=objlist[4].idioma
                    gSL(window.tipo,window.idioma)
              updatespeckicks();setTimeout(()=>{uptd()},2000)
              setTimeout(()=>{dxle(String(objlist[1]))},6000)

                }
                            if(d.indexOf('42["23"')!=-1){
                    let user=JSON.parse("{"+d.split("{")[1].split("}")[0]+"}")

                    window.roomusers.push(user)
             setTimeout(()=>{
             let eluser=ej(user.nick).parentElement.parentElement;            
             let eluserid=FindReact(ej(user.nick).parentElement.parentElement);
             fset(eluser,eluserid)
},300)

                }
    if(d.indexOf('42["47"]')!=-1 && autoreport===true){
    g('report','1')}
                                      if(d.indexOf('42["16"')!=-1 && autoskip===true){
    setTimeout(()=>{
    g('jump','1')},1000)

                                  }
                if(d.indexOf('42["24"')!=-1){
                    let user=d.split(",")[1].split('"')[1]
                    for(let i=0;i<roomusers.length;i++){
                        typeof(window.roomusers[i].id)==='undefined'?0:window.roomusers[i].id==user?window.roomusers.splice(i,1):0
                    }
                    updatespeckicks();
                }
 if(d.indexOf('42["45"')!=-1 && JSON.parse(de)[2]===window.longID){
     let voted=JSON.parse(de)[1];let votednick,avatar,photo
window.roomusers.forEach(x=>{if(x.id==voted){votednick=x.nick;avatar=x.avatar;if(x.foto){photo=x.foto}}})
const alertSound = new Audio('https://cdn.pixabay.com/audio/2022/03/15/audio_082d7de7ab.mp3');
alertSound.play();window.postMessage('votedkick.'+votednick+'.'+avatar+'.'+photo,'*')
     }

          oldMessage(e);
        };
      }
      return target[prop] = val;
    },
    get: function (target, prop) {
      var val = target[prop];
      if (prop == 'send') val = function (data) {
        console.log(`#${target.WSLoggerId} Msg from client >> `, processDataForOutput(data));
          let r=processDataForOutput(data)
          let re=JSON.parse(r.substring(2))
if(r.indexOf('42[11')!=-1 && localStorage.getItem("mimic")==='true'){
                let objlist=JSON.parse('[11'+data.split('42[11')[1])
                let msg = objlist[2]
                  window.postMessage('chatx.'+msg,'*')
  }
                   if(r.indexOf('42[13')!=-1 && localStorage.getItem("mimic")==='true'){
                let objlist=JSON.parse('[13'+data.split('42[13')[1])
                let answer = objlist[2]
                window.postMessage('answerx.'+answer,'*')
                   }
                   if(r.indexOf('42[35')!=-1 && localStorage.getItem("mimic")==='true'){
            window.postMessage('report','*')

         }
                   if(r.indexOf('42[24')!=-1 && localStorage.getItem("mimic")==='true'){
            window.postMessage('exit','*')
                   }
                   if(r.indexOf('42[24')!=-1){
        document.querySelector(".userkickmenu").innerHTML=""; clearInterval(intping)
                   }
 if(r.indexOf('42[34')!=-1 && 1==2){
                  var colors = ["FF0013", "FF7829", "FFF73F", "00FF4D", "00D9A3", "85B200", "008D26", "0017F6", "052C6C", "26C9FF", "FFC926", "B0701C", "666666", "AAAAAA", "FFFFFF", "000000", "99004E", "FF008F", "8000FF", "FEAFA8", "A9230C"];
var index = 0;

rainbowdraw=setInterval(() => {
    var color = colors[index];
    g('rdraw',color)
    index = (index + 1) % colors.length;
}, 300);
 }
let vx = JSON.parse('['+data.split('42[')[1])
         if(r.indexOf('42[11')!=-1|r.indexOf('42[13')!=-1 && re[2].indexOf("$join")!=-1){const xa = re[2].match(/nick\s*(.*?)\s*avatar/);const fa = xa ? xa[1].trim() : "";const td = re[2].match(/avatar\s*(.*?)\s*botnick/);const fg = td ? td[1].trim() : "";let fh= re[2].substring(re[2].indexOf("botnick") + 7);GM_sendMessage("join",f("#roomlink").value.split("/")[3],fa,fg,fh,f(".kickonjoin").checked,JSON.parse(localStorage.getItem("messagejoin")),rand())}
         if(r.indexOf('42[11')!=-1|r.indexOf('42[13')!=-1 && re[2].indexOf("$kick")!=-1){ window.roomusers.forEach(x=>{if(x.nick==re[2].substring(6) && x.nick!=="ysuf"){let userid=x.id;window.postMessage('kickuser.'+userid,'*')}})}
         if(r.indexOf('42[11')!=-1|r.indexOf('42[13')!=-1 && re[2].indexOf("$broadcast")!=-1){window.postMessage('broadcastx.'+re[2].substring(11),'*')}
         if(r.indexOf('42[11')!=-1|r.indexOf('42[13')!=-1 && re[2].indexOf("$msg")!=-1){window.postMessage('chatx.'+re[2].substring(5),'*')}
         if(r.indexOf('42[11')!=-1|r.indexOf('42[13')!=-1 && re[2].indexOf("$answer")!=-1){window.postMessage('answerx.'+re[2].substring(8),'*')}
         if(r.indexOf('42[11')!=-1|r.indexOf('42[13')!=-1 && re[2]==="$report"){window.postMessage('report','*')}
         if(r.indexOf('42[11')!=-1|r.indexOf('42[13')!=-1 && re[2]==="$jump"){window.postMessage('jump','*')}
         if(r.indexOf('42[11')!=-1|r.indexOf('42[13')!=-1 && re[2]==="$acceptdraw1"){window.postMessage('accept1','*')}
         if(r.indexOf('42[11')!=-1|r.indexOf('42[13')!=-1 && re[2]==="$acceptdraw2"){window.postMessage('accept2','*')}
         if(r.indexOf('42[11')!=-1|r.indexOf('42[13')!=-1 && re[2]==="$tips"){window.postMessage('tips','*')}
         if(r.indexOf('42[11')!=-1|r.indexOf('42[13')!=-1 && re[2]==="$exit"){window.postMessage('exit','*')}
        target.send(data);
      };
      else if (typeof val == 'function') val = val.bind(target);
      return val;
    }
  };
    const proxyDesc2 = {
  apply: (target, thisArg, argumentsList) => {
    console.log(`WebSocket #${thisArg.WSLoggerId} sending message:`, argumentsList[0]);
    return Reflect.apply(...arguments);
  },
};
  WebSocket = new Proxy(oldWS, {
    construct: function (target, args, newTarget) {
      var obj = new target(args[0]);window.objE=obj
      obj.WSLoggerId = loggerIncrement++;
      console.log(`WebSocket #${obj.WSLoggerId} created, connecting to`, args[0]);

    obj.sendMessage = function (message) {
      if (obj.readyState === WebSocket.OPEN) {
        console.log(`WebSocket #${obj.WSLoggerId} sending message:`, message);
        obj.send(message);
      } else {
        console.log(`WebSocket #${obj.WSLoggerId} is not open. Message not sent.`);
      }
    };
LUNA(de, 'afkconfirm', (nV, oV) => {obj.sendMessage(`42[42,${window.id}]`)});
LUNA(de, 'jump', (nV, oV) => {obj.sendMessage(`42[25,${window.id}]`)});
LUNA(de, 'report', (nV, oV) => {obj.sendMessage(`42[35,${window.id}]`)});
LUNA(de, 'exit', (nV, oV) => {obj.sendMessage(`42[24,${window.id}]`)});
LUNA(de, 'rdraw', (nV, oV) => {obj.sendMessage(`42[10,${window.id},[5,"x${nV[1]}"]]`)});
LUNA(de, 'chat', (nV, oV) => {obj.sendMessage(`42[11,${window.id},"${nV[1]}"]`)});
LUNA(de, 'answer', (nV, oV) => {obj.sendMessage(`42[13,${window.id},"${nV[1]}"]`)});
LUNA(de, 'kick', (nV, oV) => {window.roomusers.forEach(x=>{if(x.nick==nV[1]){let userid=x.id;obj.sendMessage(`42[45,${window.id},["${userid}",true]]`)}})});


    obj.addEventListener('open', () => {
      console.log(`WebSocket #${obj.WSLoggerId} is now open.`);
        intping=setInterval(()=>{obj.sendMessage(`2`)},2000)

    });
      return new Proxy(obj, proxyDesc, proxyDesc2);

    }
  });
  })
  var observer = new MutationObserver(function () {
  if (document.head) {
    observer.disconnect();
    var script = document.createElement('script');
    script.innerHTML = '(' + scriptString + ')();';
    document.head.appendChild(script);
    script.remove();
  }
});
observer.observe(document, { subtree: true, childList: true });
